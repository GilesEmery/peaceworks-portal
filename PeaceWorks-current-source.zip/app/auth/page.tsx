import AuthPageClient from "../../components/auth/AuthPageClient";

type AuthPageProps = {
  searchParams?: Promise<Record<string, string | string[] | undefined>>;
};

export default async function AuthPage({ searchParams }: AuthPageProps) {
  const resolvedSearchParams = searchParams ? await searchParams : {};
  const next = resolvedSearchParams.next;

  return <AuthPageClient nextPath={typeof next === "string" ? next : undefined} />;
}

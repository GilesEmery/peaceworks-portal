import type { Metadata } from "next";

import SiteFooter from "../components/layout/SiteFooter";
import SiteHeader from "../components/layout/SiteHeader";
import HomePage from "../components/public/home/HomePage";

export const metadata: Metadata = {
  title: "PeaceWorks | Peace Made Practical",
  description:
    "PeaceWorks equips business leaders to build cultures where trust holds under pressure.",
  openGraph: {
    title: "PeaceWorks | Peace Made Practical",
    description:
      "A relational operating system for calm leadership, conflict repair, and cultures where trust holds under pressure.",
    type: "website",
  },
};

export default function Home() {
  return (
    <main className="portal-page">
      <SiteHeader />
      <HomePage />
      <SiteFooter />
    </main>
  );
}
